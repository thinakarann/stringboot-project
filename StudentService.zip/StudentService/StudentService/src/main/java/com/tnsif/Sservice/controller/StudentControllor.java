package com.tnsif.Sservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tnsif.Sservice.entity.Student;
import com.tnsif.Sservice.repository.StudentRepository;

@RestController
@RequestMapping("/student")

public class StudentControllor {
	@Autowired
	StudentRepository repo;

	@PostMapping
	public Student addEmployee(@RequestBody Student stu) {
		return repo.save(stu);
	}

	@GetMapping
	public List<Student> getEmployee() {
		return repo.findAll();
	}

	@GetMapping("/{id}")
	public Student getStudentByid(@PathVariable Long id) {
		return repo.findById(id).get();
	}

	@DeleteMapping("/{id}")
	public void deleteStudent(@PathVariable Long id) {
		repo.deleteById(id);
	}

	@PutMapping("/emp{id}")
	public Student updateStudent(@PathVariable Long id, @RequestBody Student stu) {
		stu.setId(id);
		return repo.save(stu);

	}

}
